// scope
// 1. Global scope
// 2. Local scope
var a = 1;

function random(){
	var b = Math.random();
}

random();