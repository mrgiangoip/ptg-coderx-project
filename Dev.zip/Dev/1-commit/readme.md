This project is just a demo how to use git
// git init
// git status
// git add
// git commit

// git log
// git show
// git diff

// working directory
// staging area
// git repository

// git checkout -- <file>
// get reset

// git checkout -b <branch> (branching)
// git checkout <branch>
// git merge

// git reset --soft <to commit>
// git reset --mixed <to commit>
// git reset --hard <to commit>

// git revert <commit>
// .gitignore