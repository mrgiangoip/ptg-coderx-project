-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 27, 2023 at 04:00 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gomhang_khachvi`
--

-- --------------------------------------------------------

--
-- Table structure for table `cn_to_vn_transfer`
--

CREATE TABLE `cn_to_vn_transfer` (
  `id` int(6) UNSIGNED NOT NULL,
  `bank_china` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exchange_rate` float NOT NULL,
  `transfer_fee` float NOT NULL,
  `amount_to_transfer` float NOT NULL,
  `recipient_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `converted_amount` float NOT NULL,
  `bank_vietnam` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `checkbox_checked` tinyint(1) NOT NULL,
  `user_id` int(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cn_to_vn_transfer`
--

INSERT INTO `cn_to_vn_transfer` (`id`, `bank_china`, `exchange_rate`, `transfer_fee`, `amount_to_transfer`, `recipient_name`, `converted_amount`, `bank_vietnam`, `checkbox_checked`, `user_id`) VALUES
(3, 'GTCB', 3330, 10, 10000, 'lekim120876', 33300000, 'GICBC', 0, 7),
(4, 'GTCB', 3330, 10, 20000, 'lekim120876', 66600000, 'GICBC', 0, 8);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fullname`) VALUES
(7, '0936753881', '$2y$10$SiL1tyU2ebIojoo8zQvdQe7Cxtk7OZ1eOAT7sX4Iyhu9YHd5DBufu', 'Pháº¡m Tuáº¥n Giang'),
(8, '0936753882', '$2y$10$KfH/2L8AMtg6JZ5sNrNSReU99xCyFty.1z6PgdbwjNtXOfo.41ZwO', 'Pháº¡m Thanh BÃ¬nh');

-- --------------------------------------------------------

--
-- Table structure for table `vn_to_cn_transfer`
--

CREATE TABLE `vn_to_cn_transfer` (
  `id` int(11) UNSIGNED NOT NULL,
  `bank_name_vn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount_vn` double NOT NULL,
  `exchange_rate` double NOT NULL,
  `fee` double NOT NULL,
  `amount_cn` double GENERATED ALWAYS AS (`amount_vn` / `exchange_rate` - `fee`) STORED,
  `recipient_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bank_name_cn` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `checked` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vn_to_cn_transfer`
--

INSERT INTO `vn_to_cn_transfer` (`id`, `bank_name_vn`, `amount_vn`, `exchange_rate`, `fee`, `recipient_name`, `bank_name_cn`, `user_id`, `checked`) VALUES
(10, 'GTCB', 100000000, 3340, 20, 'Bình Phát Logistics C', 'GICBC', 7, 0),
(20, 'GTCB', 200000000, 3340, 20, 'Bình Phát Logistics C', 'GICBC', 8, 0),
(21, 'GTCB', 100000000, 3340, 20, 'Bình Phát Logistics C', 'GICBC', 8, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cn_to_vn_transfer`
--
ALTER TABLE `cn_to_vn_transfer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vn_to_cn_transfer`
--
ALTER TABLE `vn_to_cn_transfer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cn_to_vn_transfer`
--
ALTER TABLE `cn_to_vn_transfer`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vn_to_cn_transfer`
--
ALTER TABLE `vn_to_cn_transfer`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
